package com.todolist.todolist.controller;

import com.todolist.todolist.entity.TodoList;
import com.todolist.todolist.service.TodoListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author
 * @data 2022/12/27 19:01
 */
@RestController
@RequestMapping("todoList")
public class TodoListController {

    @Autowired
    private TodoListService listService;

    @ResponseBody
    @RequestMapping("/list")
    public Object list(){
        return listService.queryAll();
    }

    @ResponseBody
    @RequestMapping("/get")
    public Object get(@RequestParam("id") Integer id){
        TodoList list = listService.get(id);
        return list;
    }

    @ResponseBody
    @RequestMapping("/update/{id}")
    public Object update(@PathVariable("id") String id){
        int state = listService.update(Integer.valueOf(id));
        return state;
    }

    @ResponseBody
    @RequestMapping("/add")
    public Object add(TodoList list){
        int state = listService.add(list);
        return state;
    }

    @ResponseBody
    @RequestMapping("/del")
    public Object del(@RequestParam("id") Integer id){
        int state = listService.del(id);
        return state;
    }
}
