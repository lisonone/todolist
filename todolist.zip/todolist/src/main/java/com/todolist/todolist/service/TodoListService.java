package com.todolist.todolist.service;

import com.todolist.todolist.entity.TodoList;

import java.util.List;

public interface TodoListService {
    List<TodoList> queryAll();

    TodoList get(Integer id);

    int update(Integer id);

    int add(TodoList list);

    int del(Integer id);
}
