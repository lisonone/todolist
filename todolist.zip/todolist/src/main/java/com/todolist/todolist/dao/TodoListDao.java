package com.todolist.todolist.dao;

import com.todolist.todolist.entity.TodoList;
import org.apache.ibatis.annotations.*;

import java.util.List;
@Mapper
public interface TodoListDao {

    @Select("select * from todolist")
    List<TodoList> queryAll();

    @Select("select * from todolist where id = #{id}")
    TodoList get(@Param("id") Integer id);

    @Update("<script> update todolist" +
            "<set> <if test=\"title != null and title != ''\">" +
            "title = #{title}," +
            "</if>" +
            "<if test=\"state != null and state != ''\">" +
            "state = #{state}" +
            "</if> </set>" +
            " where id = #{id}" +
            "</script> ")
    int update(@Param("id")Integer id,@Param("title")String title,@Param("state")String state);

    @Insert("insert into todolist(title,state) values (#{title},#{state})")
    int add(@Param("title")String title,@Param("state")String state);

    @Delete("delete from todolist where id = #{id}")
    int del(@Param("id")Integer id);
}
