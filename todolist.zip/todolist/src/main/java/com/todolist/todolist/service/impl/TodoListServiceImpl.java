package com.todolist.todolist.service.impl;

import com.todolist.todolist.dao.TodoListDao;
import com.todolist.todolist.entity.TodoList;
import com.todolist.todolist.service.TodoListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author
 * @data 2022/12/27 19:01
 */
@Service
public class TodoListServiceImpl implements TodoListService {
    @Resource
    private TodoListDao listDao;

    @Override
    public List<TodoList> queryAll() {
        return listDao.queryAll();
    }

    @Override
    public TodoList get(Integer id) {
        return listDao.get(id);
    }

    @Override
    public int update(Integer id) {
        TodoList todoList = listDao.get(id);
        todoList.setState(todoList.getState().equals("1") ? "0" : "1");
        return listDao.update(todoList.getId(), todoList.getTitle(), todoList.getState());
    }

    @Override
    public int add(TodoList list) {
        return listDao.add(list.getTitle(), list.getState());
    }

    @Override
    public int del(Integer id) {
        return listDao.del(id);
    }
}
