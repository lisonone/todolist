package com.todolist.todolist.entity;

import lombok.Data;

/**
 * @author
 * @data 2022/12/27 19:05
 */
@Data
public class TodoList {
    private Integer id;
    private String title;
    private String state;
}
